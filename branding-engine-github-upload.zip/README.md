# Branding Engine Prototype

This repository contains a modular, AI-enhanced branding engine. It allows users to:

- Upload logos
- Generate AI taglines
- Create branding packs
- Apply branding to documents

## How to Use (Live on GitHub Pages)

1. Clone or upload this repository to GitHub
2. Go to Settings > Pages
3. Select branch: `main` and root folder `/`
4. GitHub will provide a public URL (e.g., https://yourusername.github.io/branding-engine-prototype/)

You can now use the app directly in the browser.
